//
//  IAPHelper.m
//  InAppRage
//
//  Created by Ray Wenderlich on 2/28/11.
//  Copyright 2011 Ray Wenderlich. All rights reserved.
//

#import "IAPHelper.h"
#import "JSON.h"

#define ITMS_PROD_VERIFY_RECEIPT_URL        @"https://buy.itunes.apple.com/verifyReceipt"
#define ITMS_SANDBOX_VERIFY_RECEIPT_URL     @"https://sandbox.itunes.apple.com/verifyReceipt";

@implementation IAPHelper
@synthesize productIdentifiers = _productIdentifiers;
@synthesize products = _products;
@synthesize purchasedProducts = _purchasedProducts;
@synthesize request = _request;

- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers
{
    NSLog(@"Break Point -   2");
    if ((self = [super init])) {
        
        // Store product identifiers
        _productIdentifiers = [productIdentifiers retain];
        
        // Check for previously purchased products
        NSMutableSet * purchasedProducts = [NSMutableSet set];
        for (NSString * productIdentifier in _productIdentifiers)
        {
            BOOL productPurchased = [[NSUserDefaults standardUserDefaults] boolForKey:productIdentifier];
            if (productPurchased)
            {
                [purchasedProducts addObject:productIdentifier];
                NSLog(@"Previously purchased: %@", productIdentifier);
            }
            else
                NSLog(@"Not purchased: %@", productIdentifier);
        }
        self.purchasedProducts = purchasedProducts;
                        
    }
    return self;
}

- (void)requestProducts
{
    NSLog(@"Break Point -   5");
    NSLog(@"%@",_productIdentifiers);
    self.request = [[[SKProductsRequest alloc] initWithProductIdentifiers:_productIdentifiers] autorelease];
    _request.delegate = self;
    [_request start];
    
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    NSLog(@"Break Point -   6");
    NSLog(@"Received products results...");   
    self.products = response.products;
    NSLog(@"%@",self.products);
    self.request = nil;    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductsLoadedNotification object:_products];    
}

- (void)recordTransaction:(SKPaymentTransaction *)transaction
{
    NSLog(@"Break Point -   7");
    // TODO: Record the transaction on the server side...    
}

- (void)provideContent:(NSString *)productIdentifier
{
    NSLog(@"Break Point -   8");
    NSLog(@"Toggling flag for: %@", productIdentifier);
    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:productIdentifier];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [_purchasedProducts addObject:productIdentifier];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductPurchasedNotification object:productIdentifier];
    
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction
{
    NSLog(@"Break Point -   9");
    NSLog(@"completeTransaction...");
    BOOL varification = [self VarifyPurchaseReceipt:transaction];
    
    [[NSUserDefaults standardUserDefaults] setObject:transaction.transactionReceipt forKey:@"MyProduct"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"MyProduct"]);
    
    NSLog(@"%c",varification);
    [self recordTransaction: transaction];
    [self provideContent: transaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction
{
    
    NSLog(@"restoreTransaction...");
    
    [self recordTransaction: transaction];
    [self provideContent: transaction.originalTransaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}

- (void)restoreCompletedTransactions {
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction
{
    
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        NSLog(@"Transaction error: %@", transaction.error.localizedDescription);
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductPurchaseFailedNotification object:transaction];
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                NSLog(@"Break Point -   01");
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                NSLog(@"Break Point -   02");
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                NSLog(@"Break Point -   03");
                [self restoreTransaction:transaction];
            default:
                break;
        }
    }
}

+ (NSString*) encode:(const uint8_t*) input length:(NSInteger) length {
  static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  
  NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
  uint8_t* output = (uint8_t*)data.mutableBytes;
  
  for (NSInteger i = 0; i < length; i += 3) {
      NSInteger value = 0;
      for (NSInteger j = i; j < (i + 3); j++) {
          value <<= 8;
          
          if (j < length) {
              value |= (0xFF & input[j]);
          }
      }
      
      NSInteger index = (i / 3) * 4;
      output[index + 0] =                    table[(value >> 18) & 0x3F];
      output[index + 1] =                    table[(value >> 12) & 0x3F];
      output[index + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
      output[index + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
  }
  
  return [[[NSString alloc] initWithData:data
                                encoding:NSASCIIStringEncoding] autorelease];
}
                                              
- (void)buyProductIdentifier:(NSString *)productIdentifier {
    
    NSLog(@"Buying %@...", productIdentifier);
    
    SKPayment *payment = [SKPayment paymentWithProductIdentifier:productIdentifier];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
    
}



- (void)dealloc
{
    [_productIdentifiers release];
    _productIdentifiers = nil;
    [_products release];
    _products = nil;
    [_purchasedProducts release];
    _purchasedProducts = nil;
    [_request release];
    _request = nil;
    [super dealloc];
}


-(BOOL)VarifyPurchaseReceipt:(SKPaymentTransaction *)transection
{
    NSLog(@"Break Point -   009");
    BOOL isVerified = FALSE;
    
    NSString *jsonObjectString = [self base64forData:transection.transactionReceipt];
    
    NSString *payload = [NSString stringWithFormat:@"{\"receipt-data\" : \"%@\",\"password\" : \"46419db713b249d3ad1cb9886f7c05e0\"}",jsonObjectString];
    //
    
    NSData *payloadData = [payload dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *serverURL = ITMS_SANDBOX_VERIFY_RECEIPT_URL;
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:serverURL]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:payloadData];
    
    NSURLResponse *response;
    NSError *error;
    
    NSData *dataResp = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString* varifivation = [[NSString alloc]initWithData:dataResp encoding:NSUTF8StringEncoding];
    
    NSDictionary* dict = [NSDictionary dictionaryWithDictionary:[varifivation JSONValue]];
    NSLog(@"%@",dict);
    int status = [[dict valueForKey:@"status"]intValue];
    
    if(status == 0)
    {
        isVerified = TRUE;
    }
    return isVerified;
}

-(NSString*)base64forData:(NSData*)theData 
{
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] autorelease];
}
#pragma mark
#pragma mark Base 64 encoding



-(NSString *)encodeBase64:(const uint8_t *)input length:(NSInteger)length
{
#warning Replace this method.
    return nil;
}


- (NSString *)decodeBase64:(NSString *)input length:(NSInteger *)length
{
#warning Replace this method.
    return nil;
}

#warning Implement this function.
char base64_encode(const void* buf, size_t size)
{ return NULL; }

#warning Implement this function.
void * base64_decode(const char* s, size_t * data_len)
{ return NULL; }
@end
