//
//  XMLViewController.m
//  XMLParsing
//
//  Created by KPIteng on 7/4/13.
//  Copyright (c) 2013 KPIteng. All rights reserved.
//

#import "XMLViewController.h"

@interface XMLViewController ()

@end

@implementation XMLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    tagNameYouWant = [[NSDictionary alloc]initWithObjectsAndKeys:@"title",@"title",@"link",@"link",@"description",@"description",@"pubDate",@"pubDate", nil];
    
    //NSString *str_2 = @"http://www.openxcelluk.info/clinical_live/web_services/profile.php?id=284";
    //NSString *str_2 = @"http://demo.tremorvideo.com/proddev/vast/vast2Nonlinear.xml";
    NSString *str_2 = @"http://ax.phobos.apple.com.edgesuite.net/WebObjects/MZStore.woa/wpa/MRSS/newreleases/limit=50/rss.xml";
    NSLog(@"URL STRING ::-->%@",str_2);
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:[str_2 stringByAddingPercentEscapesUsingEncoding :NSUTF8StringEncoding]]];
    
    
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *urlresponse, NSData *response, NSError *error)
     {
         myXMLParser = [[NSXMLParser alloc]initWithData:response];
         [myXMLParser setDelegate:self];
         [myXMLParser setShouldResolveExternalEntities:YES];
         aryMainArray = [[NSMutableArray alloc]init];
         [myXMLParser parse];
     }];
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    if([elementName isEqualToString:@"item"]){
        tempDIC = [[NSMutableDictionary alloc] init];
    }
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    strTMP = [[NSString alloc]initWithString:string];
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    if([tagNameYouWant objectForKey:elementName])
        [tempDIC setValue:strTMP forKey:elementName];
    if([elementName isEqualToString:@"item"])
    {
        [aryMainArray addObject:tempDIC];
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser{
    
    NSLog(@"%@",aryMainArray);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
