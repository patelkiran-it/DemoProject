//
//  XMLViewController.h
//  XMLParsing
//
//  Created by KPIteng on 7/4/13.
//  Copyright (c) 2013 KPIteng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMLViewController : UIViewController <NSXMLParserDelegate>
{
    NSXMLParser *myXMLParser;
    NSMutableDictionary *tempDIC;
    NSString *strTMP;
    NSMutableArray *aryMainArray;
    NSDictionary *tagNameYouWant;
}
@end
