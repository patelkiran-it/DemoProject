//
//  XMLAppDelegate.h
//  XMLParsing
//
//  Created by KPIteng on 7/4/13.
//  Copyright (c) 2013 KPIteng. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMLViewController;

@interface XMLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) XMLViewController *viewController;

@end
